'use strict';

(function ($) {
	
	
	
})(jQuery);